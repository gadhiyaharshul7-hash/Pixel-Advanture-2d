using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.Rendering.Universal;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class playerscript : MonoBehaviour
{
    public Rigidbody2D rb;
    public Animator animator;

    public float movement;
    public float speed = 5f;
    public float jumpHeight = 7f;

    public bool isGround = true;

    private bool facingRight = true;

    public Text AppleText;
    public int currentApple;
    public GameObject GameOverPanel;
    public Text AppleTe;      // drag AppleText here in the Inspector
    private int appleCount = 0;
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        GameOverPanel.SetActive(false);
    }

    void Update()
    {
        // Horizontal Movement
        movement = 0f;

        if (Keyboard.current.aKey.isPressed)
            movement = -1f;

        if (Keyboard.current.dKey.isPressed)
            movement = 1f;

        rb.linearVelocity = new Vector2(
            movement * speed,
            rb.linearVelocity.y
        );

        // Run Animation
        if (Mathf.Abs(movement) > 0.1f)
        {
            animator.SetFloat("run", 1f);
        }
        else
        {
            animator.SetFloat("run", 0f);
        }

        // Flip Player
        if (movement < 0 && facingRight)
        {
            transform.eulerAngles = new Vector3(0, 180, 0);
            facingRight = false;
        }

        if (movement > 0 && !facingRight)
        {
            transform.eulerAngles = new Vector3(0, 0, 0);
            facingRight = true;
        }

        // Jump
        if (Keyboard.current.spaceKey.wasPressedThisFrame && isGround)
        {
            Jump();

            isGround = false;

            animator.SetBool("jump", true);
        }
    }

    void Jump()
    {
        rb.linearVelocity = new Vector2(
            rb.linearVelocity.x,
            jumpHeight
        );
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        // Death
        if (collision.collider.CompareTag("Die"))
        {
            Die();
            return;
        }

        // Ground
        isGround = true;
        animator.SetBool("jump", false);
    }

    // Apple Collection
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Apple"))   // keep whatever check you already use
        {
            appleCount++;
            AppleText.text = appleCount.ToString();
            Debug.Log("AppleText!");
            Destroy(other.gameObject);
        }

        if (other.CompareTag("Cup"))
        {
            Debug.Log("Victory!");
            other.CompareTag("Cup");
            SceneManager.LoadScene(0);
        }
    }
        


    void Die()
    {
            Debug.Log("Player Died.");

            GameOverPanel.SetActive(true);

            Destroy(this.gameObject);
    }
}