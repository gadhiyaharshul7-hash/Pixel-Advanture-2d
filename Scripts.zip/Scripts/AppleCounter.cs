using UnityEngine;
using UnityEngine.UI;   // for Text (Legacy)

public class AppleCounter : MonoBehaviour
{
    public static AppleCounter Instance;
    public Text appleText;
    private int count = 0;

    void Awake()
    {
        Instance = this;
    }

    public void AddApple()
    {
        count++;
        appleText.text = count.ToString();
    }
}