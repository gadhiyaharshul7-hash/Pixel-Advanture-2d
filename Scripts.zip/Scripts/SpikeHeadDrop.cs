using UnityEngine;

public class SpikeHeadDrop : MonoBehaviour
{
    public Transform player;           // optional: auto-found if empty
    public Animator animator;          // optional: auto-found if empty
    public float detectWidth = 1.5f;   // how close left/right the player must be
    public float fallDistance = 6f;    // how far it drops before stopping
    public float fallSpeed = 12f;
    public float riseSpeed = 3f;
    public float waitTime = 1f;

    private Vector3 startPos;
    private enum State { Idle, Falling, Waiting, Rising }
    private State state = State.Idle;
    private float timer;

    void Start()
    {
        startPos = transform.position;

        if (animator == null) animator = GetComponent<Animator>();

        if (player == null)
        {
            GameObject p = GameObject.Find("Player");   // must match the Hierarchy name
            if (p != null) player = p.transform;
            else Debug.LogError("SpikeHead: no object named 'Player' found in the scene!");
        }
    }

    void Update()
    {
        if (player == null) return;

        switch (state)
        {
            case State.Idle:
                float xDistance = Mathf.Abs(player.position.x - transform.position.x);
                if (xDistance < detectWidth && player.position.y < transform.position.y)
                    state = State.Falling;
                break;

            case State.Falling:
                transform.position += Vector3.down * fallSpeed * Time.deltaTime;
                if (transform.position.y <= startPos.y - fallDistance)
                {
                    if (animator != null) animator.Play("SpikeHead_BottomHit");
                    timer = waitTime;
                    state = State.Waiting;
                }
                break;

            case State.Waiting:
                timer -= Time.deltaTime;
                if (timer <= 0)
                {
                    if (animator != null) animator.Play("SpikeHead_Idle");
                    state = State.Rising;
                }
                break;

            case State.Rising:
                transform.position = Vector3.MoveTowards(transform.position, startPos, riseSpeed * Time.deltaTime);
                if (transform.position == startPos) state = State.Idle;
                break;
        }
    }
}