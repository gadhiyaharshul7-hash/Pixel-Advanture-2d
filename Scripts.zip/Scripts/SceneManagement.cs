using System.Net.NetworkInformation;
using UnityEngine;
using UnityEngine.SceneManagement;
public class SceneManagement : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    public void Play()
    {
        SceneManager.LoadScene("Level1"); // or use build index: SceneManager.LoadScene(1);
    }

    public void Exit()
    {
        Debug.Log("Exit!");
        Application.Quit();
    }
    public void Menu()
    {
        SceneManager.LoadScene("Menu");   // must match your menu scene name exactly
    }

}



