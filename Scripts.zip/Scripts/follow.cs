using UnityEngine;

public class follow : MonoBehaviour
{
    public Transform player;
    public float smoothness = 2f;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
         // Player destroyed
        if (player == null)
        {
            return;
        }

        // Follow player
        Vector3 targetPos = new Vector3(
            player.position.x,
            transform.position.y,
            transform.position.z
        );

        transform.position = Vector3.Lerp(
            transform.position,
            targetPos,
            smoothness * Time.deltaTime
        );
    }
}
